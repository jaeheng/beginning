<?php
/*
Template Name:beginning
Description:简洁优雅，双栏布局，个人介绍，金v闪亮你的自媒体之路
Version:1.0
Author:jaeheng
Author Url:http://fntheme.com
Sidebar Amount:1
*/
if (!defined('EMLOG_ROOT')) exit('error!');
require_once View::getView('module');
require_once View::getView('config');
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="keywords" content="<?php echo $site_key; ?>" />
    <meta name="description" content="<?php echo $site_description; ?>" />
    <meta name="generator" content="emlog" />
    <title><?php echo $site_title; ?></title>
    <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
    <link rel="stylesheet" href="//at.alicdn.com/t/font_gz3j33wago06n7b9.css">
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/style.css?version=v1.0.0">
    <link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
    <script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
</head>
<body>
<!--[if lte IE 8]>
<div id="browsehappy" style="text-align: center">您正在使用的浏览器版本过低，请<a href="http://browsehappy.com/" target="_blank"><strong>升级您的浏览器</strong></a>，获得最佳的浏览体验！</div>
<![endif]-->

<?php doAction('index_head'); ?>

<!--头部区域-->
<header id="header" class="header">
    <div class="container">
        <a href="<?php echo BLOG_URL; ?>" class="avatar">
            <img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="头像">
            <em class="gold-v"></em>
        </a>
        <div class="userinfo">
            <h1 class="username">
                <?php echo $blogname; ?>
                <a href="<?php echo $config['weibo_url'];?>" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/weibo_48_48.png" alt="weibo"></a>
            </h1>
            <h3 class="userdesc"><?php echo $bloginfo; ?></h3>
            <ul class="count">
                <li class="item">
                    <div class="num">234</div>
                    文章
                </li>
                <li class="item">
                    <div class="num">23039213</div>
                    阅读量
                </li>
            </ul>
        </div>
        <div class="third-entry">
            <img src="<?php echo TEMPLATE_URL; ?>images/payme.png" alt="wechat">
            <p>关注微信公众号</p>
        </div>
    </div>
</header>
<!--头部区域 ／-->

<!--导航-->
<div class="menu-box">
    <div class="container">
        <a href="javascript:;" class="icon-menu toggle-open" data-target="menu">
            <i class="icon-menu-item"></i>
            <i class="icon-menu-item"></i>
            <i class="icon-menu-item"></i>
        </a>
        <?php blog_navi();?>
        <form action="<?php echo BLOG_URL; ?>index.php" method="get" class="pull-right search" id="search-form">
            <input type="search" name="keyword" class="input" placeholder="search..." />
        </form>
    </div>
</div>
<!--导航 ／-->