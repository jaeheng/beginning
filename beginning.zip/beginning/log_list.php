<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--面包屑导航-->
<div class="breadthumb">
    <div class="container">
        <i class="iconfont icon-notice"></i>
        Welcome to my blog
    </div>
</div>
<!--面包屑导航-->
<?php doAction('index_loglist_top'); ?>
<div class="main container">
    <div class="content-wrap">
        <div class="content" id="content">
            <ul class="log_list">
                <?php
                if (!empty($logs)):
                    foreach($logs as $value):
                        preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['log_description'], $img);
                        $imgext = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/article.jpg';
                        preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
                        $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/article.jpg';
                        ?>
                        <li class="log_list_item">
                            <div class="tag"><?php blog_sort($value['logid']); ?></div>
                            <a href="echo_log.html" class="pic-link"><img src="<?php if($imgext):{ echo $imgext;} else:{ echo $imgsrc;} endif;?>" alt="<?php echo $value['log_title']; ?>"></a>
                            <h3 class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a>
                            </h3>

                            <div class="info">
                                <i class="iconfont icon-user"></i> <?php blog_author($value['author']); ?>
                                <i class="iconfont icon-time"></i> <span class="time"><?php echo gmdate('Y-n-j', $value['date']); ?></span>
                                <i class="iconfont icon-view"></i> <span class="views"><?php echo $value['views']; ?></span>
                                <?php editflg($value['logid'],$value['author']); ?>
                            </div>
                            <div class="description">
                                <?php echo subString(strip_tags($value['log_description']),0,200);?>
                            </div>
                            <div class="tags">
                                <?php blog_tag($value['logid']); ?>
                            </div>
                        </li>
                        <?php
                    endforeach;
                else:
                    ?>
                    <li class="log_list_item">未找到</li>
                    <li class="log_list_item">抱歉，没有符合您查询条件的结果。</li>
                <?php endif;?>
            </ul>
            <!--分页-->
            <div class="pagination" id="pagenavi">
                <?php echo $page_url;?>
            </div>
            <!--分页 ／-->
        </div>
    </div>
    <?php include View::getView('side');?>
    <div class="sidebar" id="sidebar">
        <div class="widget widget-tags">
            <h3>我的标签</h3>
            <div class="widget-inner">
                <a href="" class="label label-tag">财经达人</a>
                <a href="" class="label label-tag">选择器</a>
                <a href="" class="label label-tag">达人</a>
                <a href="" class="label label-tag">自媒体</a>
                <a href="" class="label label-tag">卧槽</a>
                <a href="" class="label label-tag">财经达人</a>
                <a href="" class="label label-tag">视频直播</a>
                <a href="" class="label label-tag">百度</a>
                <a href="" class="label label-tag">腾讯QQ</a>
                <a href="" class="label label-tag">李彦宏</a>
                <a href="" class="label label-tag">财经达人</a>
                <a href="" class="label label-tag">财经达人</a>
                <a href="" class="label label-tag">财经达人</a>
                <a href="" class="label label-tag">财经达人</a>
            </div>
        </div>
        <div class="widget widget-comment">
            <h3>最新留言</h3>
            <ul>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">御风牧云007</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">大争之世，哪一国敢妄言灭一国？</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">雾</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">日狗花钱买的记者，西方的走狗</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">烽烟无限</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">好好好，我们一群农夫你们满意了吧！开战了别你们一群勇士被打成农夫了，农夫没什么怕的，勇士被打的丢盔弃甲成农夫，那可就要对调了，战胜勇士的农夫要穿上勇士的衣服成为新农夫，战败被丢盔卸甲的勇士就只有去做农夫了</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">ailin</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">战争是残酷的，但也有其必然性，中美必有一战，只是时间问题，战争规模问题，因为人类社会还没有出现过不发生战争的历史，也不可能维持不发生战争的历史，这是规律，无法改变。如果现在或短期内爆发战争，美国实力明显占优，如果往后就不好说了，越往后中国实力会越强！但即便现在就爆发战争，在美国占优的情况下开战，中国也不会输！输赢是相对的，除非你彻底占领并完全控制一个国家，否则，你即便赢得了一些战场上的优势，最终结果仍是未知！以中国如今的实力，即便军事上遭受失败，但绝不会发生被美国占领的可能，既然如此，美国最终将被中国拖垮。如果要发生核大战...那谁都不会赢</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">静静</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">日元发挥作用了？到时连农夫都打不赢，你那眼光比农夫都不如了。</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
                <li>
                    <div class="comment-inner">
                        <img class="avatar" src="images/default_avatar.png">
                        <i class="username">烽烟无限</i>
                        <span class="time">2016年12月14日</span>
                        <p class="comment-content">就从一个使用者的角度，来看看这款笔电表现如何</p>
                    </div>
                    <div class="comment-refer">
                        <i class="iconfont icon-yinhao"></i>
                        <span class="t">来源<a href="#" target="_blank">演绎优雅，XPS 13 无忌金全新体验</a></span>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="clearfix"></div>
</div>



<?php
 include View::getView('footer');
?>