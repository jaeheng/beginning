<?php
if (!defined('EMLOG_ROOT')) exit('error!');

$config = array(
    'weibo_url' => 'http://weibo.com/theheng'
);