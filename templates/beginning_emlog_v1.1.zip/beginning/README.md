# emlog插件 beginning

## 特性

1. 5种列表： 普通2列带侧边log_list.php , 2列布局log_list2.php, 3列布局log_list3.php， 图片类型列表log_list_img.php, 视频类型列表log_list_mv.php
2. 个人中心类型头部， 显示出博客的一些统计数据：文章数，阅读数，评论数
3. 遵循emlog模板开发规范
4. 侧边小工具，可用于展示二维码或qq临时会话

## 适用于
本模板是在emlog5.3.1下开发的， 完美适配该版本。 该版本也是目前 emlog 的最新版本。

## 反馈
如有疑问、建议或要提交bug，可发邮件至459269125@qq.com， 或直接加我 qq， 备注beginning