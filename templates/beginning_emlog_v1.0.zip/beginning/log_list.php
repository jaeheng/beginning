<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--面包屑导航-->
<div class="breadthumb">
    <div class="container">
        <?php if(blog_tool_ishome()):?>
        <i class="iconfont icon-notice"></i>
        Welcome to my blog
        <?php else: ?>
            <a href="<?php echo BLOG_URL; ?>" class="bread-item" title="返回首页">首页</a><!-- 首页 -->
            <?php if (isset($tag)):?>
                <a class="bread-item">包含“ <?php echo $tag; ?> ”话题的文章</a><!-- 标签 -->
            <?php elseif (isset($sortid)): ?>
                <?php global $CACHE; $sort_cache = $CACHE->readCache('sort'); ?>
                <?php  $pid = $sort_cache[$sortid]['pid'];?>
                <?php if($pid != 0):?>
                    <a class="bread-item" href="<?php echo Url::sort($pid); ?>"><?php echo $sort_cache[$pid]['sortname'];?></a>
                    <a class="bread-item" href="<?php echo Url::sort($sortid); ?>"><?php echo $sort_cache[$sortid]['sortname']; ?></a><!-- 父分类/子分类 -->
                <?php else:?>
                    <a class="bread-item" href="<?php echo Url::sort($sortid); ?>"><?php echo $sort_cache[$sortid]['sortname']; ?></a><!-- 分类 -->
                <?php endif;?>
            <?php elseif (isset($author)): ?>
                <a class="bread-item">作者：<?php echo blog_author($author); ?> 的文章</a><!-- 作者 -->
            <?php elseif (isset($keyword)):?>
                <a class="bread-item">包含搜索词 “<?php echo $keyword; ?>” 的文章</a><!-- 搜索词 -->
            <?php elseif (isset($record)):?>
                <a class="bread-item">您查看的是 “ <?php echo $record; ?> ” 年月的文章</a><!-- 归档 -->
            <?php endif;?>
        <?php endif;?>
    </div>
</div>
<!--面包屑导航-->
<?php doAction('index_loglist_top'); ?>
<div class="main container">
    <div class="content-wrap">
        <div class="content" id="content">
            <ul class="log_list">
                <?php
                if (!empty($logs)):
                    foreach($logs as $value):
                        preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['log_description'], $img);
                        $imgext = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/article.jpg';
                        preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
                        $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/article.jpg';
                        ?>
                        <li class="log_list_item">
                            <div class="tag"><?php blog_sort($value['logid']); ?></div>
                            <a href="echo_log.html" class="pic-link"><img src="<?php if($imgext):{ echo $imgext;} else:{ echo $imgsrc;} endif;?>" alt="<?php echo $value['log_title']; ?>"></a>
                            <h3 class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a>
                            </h3>

                            <div class="info">
                                <i class="iconfont icon-user"></i> <?php blog_author($value['author']); ?>
                                <i class="iconfont icon-time"></i> <span class="time"><?php echo gmdate('Y-n-j', $value['date']); ?></span>
                                <i class="iconfont icon-view"></i> <span class="views"><?php echo $value['views']; ?></span>
                                <?php editflg($value['logid'],$value['author']); ?>
                            </div>
                            <div class="description">
                                <?php echo subString(strip_tags($value['log_description']),0,200);?>
                            </div>
                            <div class="tags">
                                <?php blog_tag($value['logid']); ?>
                            </div>
                        </li>
                        <?php
                    endforeach;
                else:
                    ?>
                    <li style="background-color: #fff;padding: 30px;">未找到 <br>抱歉，没有符合您查询条件的结果。</li>
                <?php endif;?>
            </ul>
            <!--分页-->
            <div class="pagination" id="pagenavi">
                <?php echo $page_url;?>
            </div>
            <!--分页 ／-->
        </div>
    </div>
    <?php include View::getView('side');?>
    <div class="clearfix"></div>
</div>
<?php
 include View::getView('footer');
?>