<?php
if (!defined('EMLOG_ROOT')) exit('error!');

$config = array(
    'weibo_url' => 'http://weibo.com/theheng',
    'email' => 'service@fntheme.com',
    'relief' => '免责声明：本文仅代表作者个人观点，与本网站无关。其原创性以及文中陈述文字和内容未经本站证实，对本文以及其中全部或者部分内容、文字的真实性、完整性、及时性本站不作任何保证或承诺，请读者仅作参考，并请自行核实相关内容。'
);