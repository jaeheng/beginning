<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--footer-->
<footer class="footer">
    <div class="container">
        <?php widget_hot_tag(); ?>
        <div class="widget">
            <h3>联系我们</h3>
            <div class="widget-inner">
                <p>Email: <a href="mailto:<?php echo $config['email'];?>"><?php echo $config['email'];?></a></p>
                <p>Weibo: <a href="<?php echo $config['weibo_url'];?>"><?php echo $config['weibo_url'];?></a></p>
                <p><?php if (Option::get('rss_output_num')):?>
                        <a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅">RSS订阅</a>
                    <?php endif;?>
                    <?php doAction('index_footer'); ?>
                </p>
            </div>
        </div>
        <?php widget_link('合作伙伴');?>
    </div>
</footer>
<!--footer ／-->

<!--版权信息-->
<div class="copyright">
    Copyright &copy; <a href="<?php echo BLOG_URL;?>"><?php echo $blogname;?></a> && <a href="http://zhangziheng.com" target="_blank">jaeheng</a> | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> | Powered by <a href="http://www.emlog.net" title="采用emlog系统" target="_blank">emlog</a>
</div>
<!--版权信息 ／-->

<!--网站小工具-->
<div class="site-tools">
    <a href="http://zhangziheng.com" target="_blank" class="item"><i class="iconfont icon-gift"></i></a>
    <a href="javascript:;" class="item">
        <i class="iconfont icon-qrcode"></i>
        <div class="popup">
            <img src="<?php echo TEMPLATE_URL;?>images/payme.png" alt="关注公众号">
            <h3 class="title">关注公众号</h3>
        </div>
    </a>
    <a href="javascript:alert('未连接到QQ客服');" class="item"><i class="iconfont icon-qq"></i></a>
    <div class="item active gotoup"><i class="iconfont icon-up"></i></div>
</div>
<!--网站小工具 ／-->

<script src="<?php echo TEMPLATE_URL;?>js/jquery-3.1.1.min.js"></script>
<script src="<?php echo TEMPLATE_URL;?>js/main.js?version=v1.0.0"></script>
<script>prettyPrint();</script>
</body>
</html>